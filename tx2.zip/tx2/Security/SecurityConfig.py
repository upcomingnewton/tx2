InitState = 'SystemInit_Active'
InitPermission = 'SystemInit_Insert'
InitUserEmail  = 'SystemInit@init.com'
InitEntity = 'SystemInit'
InitGroupType = 'SystemInit'
InitGroup = 'SystemInit'

PermissionInsert = 'Insert'