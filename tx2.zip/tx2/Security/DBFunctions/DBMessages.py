from tx2.Misc.DBMessages import db_messages,decode

db_messages.update({
                # check user for permission
                501: 'User does not exist.',
                502: 'Requested permission is not there in the system.',
                503: 'Content Type does not exist.',
                504: 'Sorry you do not have permission to perform this operation on this object.',
                    })
    

