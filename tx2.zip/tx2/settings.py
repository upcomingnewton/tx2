
import os
#hostname = os.environ['HOSTNAME']
#print hostname

#if( hostname == 'linux-4bv4.site' ):
from conf.sarv_settings import *
#elif (hostname == 'nathron.thoughtexplore.com'):
#from conf.labs_nitin_settings import *
