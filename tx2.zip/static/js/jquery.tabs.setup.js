$(function() {
	$('#featured_slide').tabs({
		fx: {
			opacity: 'show'
		}
	}).tabs('rotate', 8000);
});