$(document).ready(function() { 
	$(".list-services a.tooltips").easyTooltip();
}); 